#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<cstdio>
using namespace std;

char zu = 0xA3;

int main(int argc, char *argv[])
{
    // ios::sync_with_stdio(false); // 不要每次cout都flush
    // cin.tie(0); //配合所有endl改成
    char temp_s[2];
    string s;
    ifstream in(argv[2]);
    // in >> temp_s;
    // cout << temp_s[0] << temp_s[1];
    while (getline(in, s))
    {
        printf("<s> ");
        for (int i = 0; i < s.length(); ++i)
        {
            if(s[i]!=' ')
            {
                cout << s[i] << s[i+1] << ' ';
                i++;
            }
            
        }
        printf("</s>\n");
    }

    int i = 0;
    return 0;
}