

dic = {'ㄅ': [], 'ㄆ': [], 'ㄇ': [], 'ㄈ': [], 'ㄉ': [], 'ㄊ': [], 'ㄋ': [], 'ㄌ': [], 'ㄍ': [], 'ㄎ': [], 'ㄏ': [], 'ㄐ': [], 'ㄑ': [],
       'ㄒ': [], 'ㄓ': [], 'ㄔ': [], 'ㄕ': [], 'ㄖ': [], 'ㄗ': [], 'ㄘ': [], 'ㄙ': [], 'ㄧ': [], 'ㄨ': [], 'ㄩ': [], 'ㄚ': [], 'ㄛ': [],
       'ㄜ': [], 'ㄝ': [], 'ㄞ': [], 'ㄟ': [], 'ㄠ': [], 'ㄡ': [], 'ㄢ': [], 'ㄣ': [], 'ㄤ': [], 'ㄥ': [], 'ㄦ': []}

file = open('./Big5-ZhuYin.map', mode='r', encoding='big5-hkscs')

for i in file:
    l = i.split(" ")
    b = l[1].split('/')
    for j in b:
        if (l[0] not in dic[j[0]]):
                dic[j[0]].append(l[0])

# print([dic['ㄅ']])
out = open('./ZhuYin-Big5.map',mode='w',encoding='big5-hkscs')
for i in dic:
	out.write(i+'\t')
	for j in dic[i]:
		out.write(j+' ')
	out.write('\n')
	for j in dic[i]:
		out.write(j+' '+j+'\n')
